# 从 Kubernetes 集群中删除节点

## 步骤描述
- 删除节点
  - 驱逐节点上运行的容器
  - 从集群中删除节点

## 验证方法

- 查看节点

  ```sh
  kubectl get nodes
  ```

# 下载依赖的资源

根据 `/package.yaml` 文件中定义的 `data.dependency` 列表，下载所有的依赖二进制文件、容器镜像等。存放到 `/cache` 目录下
